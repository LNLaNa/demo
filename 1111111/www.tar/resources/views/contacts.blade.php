@extends('layout')
@section('content')
    <div class="container d-flex flex-column justify-content-center mt-5 "  >
        <img src="img/map.jpg" alt="...">
        <p>Адрес:Пушкина 120</p>
        <p>Номер телефона:8983-800-20-20</p>
        <p>Email:Omega@mail.com</p>
    </div>
@endsection
