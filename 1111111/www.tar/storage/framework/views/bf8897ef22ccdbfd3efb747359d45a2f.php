<?php $__env->startSection('content'); ?>


    <div class="container d-flex flex-column justify-content-center"  >
        <h1 class="text-center p-4">Добавить спектакль</h1>
        <form action="<?php echo e(route('performances.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <h1>Название</h1>
                <input type="text" name="name" class="form-control">
            </div>
            <div class="mb-3">
                <h1>Дата</h1>
                <input type="date" name="date" class="form-control">
            </div>
            <div class="mb-3">
                <h1>Возраст</h1>
                <input type="number" name="age" class="form-control">
            </div>
            <div class="mb-3">
                <h1>Фото</h1>
                <input type="file" name="img" class="form-control">
            </div>
            <div class="mb-3">
                <h1>Жанры</h1>
                <select class="form-select" name="genre[]" multiple>
                    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($genre->id); ?>"><?php echo e($genre->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </div>
            <div class="mb-3">
                <h1>Цена</h1>
                <input type="text" name="price" class="form-control">
            </div>
            <button class="btn btn-primary" type="submit">Создать</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/performances/create.blade.php ENDPATH**/ ?>