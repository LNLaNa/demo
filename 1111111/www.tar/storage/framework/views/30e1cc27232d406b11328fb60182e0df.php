<?php $__env->startSection('content'); ?>
    <div class="container d-flex flex-row gap-4 flex-wrap">
        <h2>Жанры</h2>
        <a class="btn btn-dark" style="text-decoration: none;" href="<?php echo e(route('genres.create')); ?>">Добавить жанр</a>
    </div>
    <table class="table">
        <tr>
            <td>#</td>
            <td>name</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>

                <td><?php echo e($genre->name); ?></td>
                <td><a class="btn btn-dark" href="<?php echo e(route('genres.edit',$genre)); ?>">Редактировать</a></td>
                <td><form action="<?php echo e(route('genres.destroy',$genre)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn btn-dark" type="submit">Удалить</button>
                    </form></td>
            </tr> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/genres/index.blade.php ENDPATH**/ ?>