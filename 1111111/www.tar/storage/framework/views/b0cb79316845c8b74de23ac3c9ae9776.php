<?php $__env->startSection('content'); ?>
    <div class="container d-flex flex-column justify-content-center"  >
        <h1 class="text-center p-4">Редактировать жанр</h1>
        <form action="<?php echo e(route('genres.update',$genre)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="mb-3">
                <input type="text" value="<?php echo e($genre->name); ?>"  name="name" class="form-control">
            </div>
            <button class="btn btn-primary" type="submit">Редактировать</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/genres/edit.blade.php ENDPATH**/ ?>