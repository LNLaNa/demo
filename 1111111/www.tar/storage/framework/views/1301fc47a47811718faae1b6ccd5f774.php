<?php $__env->startSection('content'); ?>
    <div class="container d-flex flex-column justify-content-center mt-5 "  >
        <img src="img/map.jpg" alt="...">
        <p>Адрес:Пушкина 120</p>
        <p>Номер телефона:8983-800-20-20</p>
        <p>Email:Omega@mail.com</p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/contacts.blade.php ENDPATH**/ ?>