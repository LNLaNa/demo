<?php $__env->startSection('content'); ?>
    <div class="container d-flex flex-row gap-4 flex-wrap ">
        <div class="card" style="width: 18rem;">
            <img src="img/5f8410c42fa84dcaa496db8346e9.jpg" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">Спектакль</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-dark">Подробнее</a>
            </div>
        </div>

        <div class="card" style="width: 18rem;">
            <img src="img/5f8410c42fa84dcaa496db8346e9.jpg" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">Спектакль</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-dark">Подробнее</a>
            </div>
        </div>


        <div class="card" style="width: 18rem;">
            <img src="img/5f8410c42fa84dcaa496db8346e9.jpg" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">Спектакль</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-dark">Подробнее</a>
            </div>
        </div>

        <div class="card" style="width: 18rem;">
            <img src="img/5f8410c42fa84dcaa496db8346e9.jpg" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">Спектакль</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-dark">Подробнее</a>
            </div>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/posters.blade.php ENDPATH**/ ?>