<?php
    use App\Enums\RoleEnum;
    use Illuminate\Support\Facades\Storage;
?>

<?php $__env->startSection('style'); ?>
    <style>
        .age{
            background-color: #000000;
            color: white;
            border-radius: 50%;
            width: 48px;
            height: 48px;
            position: absolute;
            left: 235px;
            top: 5px;
            padding: 5px;
            box-shadow: -5px 8px 8px rgba(34, 60, 80, 0.32);
            /*font-size: 20px;*/
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()?->role == RoleEnum::ADMIN->value): ?>
    <a class="btn btn-dark" style="text-decoration: none;" href="<?php echo e(route('performances.create')); ?>">Добавить
        спектакль</a>
    <?php endif; ?>
    <div class="container d-flex flex-row gap-4 flex-wrap ">


        <?php $__currentLoopData = $performances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $performance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mt-3" style="width: 18rem;">
                <div class="age"><?php echo e($performance->age); ?>+</div>
                <img src="<?php echo e(Storage::url($performance->img)); ?>" class="card-img-top" style="height: 300px">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($performance->name); ?></h5>
                    <p class="card-text" style="font-size: 16px">Жанр(ы): <?php echo e($performance->genres()->implode('name',', ')); ?></p>
                    <p class="card-text" style="font-size: 16px">Цена: <?php echo e($performance->price); ?> руб.</p>
                    <p class="card-text" style="font-size: 16px">Кол-во билетов: <?php echo e($performance->tickets); ?> шт.</p>
                    <div class="buttons d-flex gap-2">
                        <a href="<?php echo e(route('performances.show', $performance)); ?>" class="btn btn-dark">Подробнее</a>
                        <?php if(auth()->user()?->role == RoleEnum::ADMIN->value): ?>
                            <form action="<?php echo e(route('performances.destroy', $performance)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button class="btn btn-danger">Удалить</button>
                            </form>
                        <?php endif; ?>
                        <?php if(auth()->user()?->role == RoleEnum::USER->value): ?>


                                <a href="<?php echo e(route('addPerformance', $performance)); ?>" class="btn btn-dark">В корзину</a>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(auth()->user()?->role == RoleEnum::USER->value): ?>
            <!-- Modal -->
            <div class="modal fade" id="cart" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Корзина</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <?php $__currentLoopData = $performancesInCart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $performance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="performance d-flex justify-content-between">
                                    <h5><?php echo e($performance->name); ?></h5>

                                    <h5><?php echo e($performance->price); ?> руб.</h5>
                                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-dark">Заказать</button>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/performances/index.blade.php ENDPATH**/ ?>