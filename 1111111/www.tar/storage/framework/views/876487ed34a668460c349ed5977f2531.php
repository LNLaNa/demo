<?php $__env->startSection('content'); ?>
    <div class="container d-flex flex-column justify-content-center"  >
        <h1 class="text-center p-4">Добавить жанр</h1>
        <form action="<?php echo e(route('genres.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <input type="text"  name="name" class="form-control">
            </div>
            <button class="btn btn-primary" type="submit">Создать</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/genres/create.blade.php ENDPATH**/ ?>