<?php $__env->startSection('content'); ?>


    <div class="container d-flex flex-column justify-content-center"  >
        <h1 class="text-center p-4">Редактировать спектакль</h1>
        <form action="<?php echo e(route('performances.update', $performance)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="mb-3">
                <h1>Название</h1>
                <input type="text" name="name" class="form-control" value="<?php echo e($performance->name); ?>">
            </div>
            <div class="mb-3">
                <h1>Дата</h1>
                <input type="date" name="date" class="form-control" value="<?php echo e($performance->date); ?>">
            </div>
            <div class="mb-3">
                <h1>Возраст</h1>
                <input type="number" name="age" class="form-control" value="<?php echo e($performance->age); ?>">
            </div>
            <div class="mb-3">
                <h1>Фото</h1>
                <input type="file" name="img" class="form-control">
            </div>
            <div class="mb-3">
                <h1>Жанры</h1>
                <select class="form-select" name="genre[]" multiple>
                    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($genre->id); ?>" <?php $__currentLoopData = $performance->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genreId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($genre->id == $genreId->id): ?> selected <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><?php echo e($genre->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </div>
            <div class="mb-3">
                <h1>Цена</h1>
                <input type="text" name="price" class="form-control" value="<?php echo e($performance->price); ?>">
            </div>
            <button class="btn btn-primary" type="submit">Создать</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/performances/edit.blade.php ENDPATH**/ ?>