<?php
    use App\Enums\RoleEnum;
    use Illuminate\Support\Facades\Storage;
?>

<?php $__env->startSection('content'); ?>









    <div class="container d-flex gap-4 mt-5">
        <img src="<?php echo e(Storage::url($performance->img)); ?>" class="card-img-top" alt="..." style="width: 250px" >
        <div class="description">
            <h3>Название: <?php echo e($performance->name); ?></h3>
            <p>Жанр(ы): <?php echo e($performance->genres()->implode('name',', ')); ?></p>
            <p>Дата: <?php echo e($performance->date); ?></p>
            <p>Возрастной ценз: <?php echo e($performance->age); ?>+</p>
            <p>Цена: <?php echo e($performance->price); ?> руб.</p>
            <?php if(auth()->user()?->role == RoleEnum::ADMIN->value): ?>
                <a href="<?php echo e(route('performances.edit', $performance)); ?>" class="btn btn-dark">Редактировать</a>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/performances/show.blade.php ENDPATH**/ ?>