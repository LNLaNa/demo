<?php

namespace App\Http\Controllers;

use App\Models\CartPerformance;
use Illuminate\Http\Request;

class CartPerformanceController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(CartPerformance $basketPerformance)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(CartPerformance $basketPerformance)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, CartPerformance $basketPerformance)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(CartPerformance $basketPerformance)
    {
        //
    }
}
